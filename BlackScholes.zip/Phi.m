function p=Phi(x)
   p=0.5*(1.+erf(x/sqrt(2)));
end